/**
 * Discord Autoposter — server.js v2.1
 * Features: Multi-channel, Image support, Smart cooldown, Auto-detect guilds/channels
 */

const express  = require('express');
const fetch    = require('node-fetch');
const path     = require('path');
const { v4: uuidv4 } = require('uuid');
const db       = require('./db');

const app  = express();
const PORT = process.env.PORT || 3000;
const DISCORD_API = 'https://discord.com/api/v10';

app.use(express.json({ limit: '2mb' }));
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// ── In-memory autopost state ───────────────────────────
const runningJobs = {};

// ── Discord API Helper ─────────────────────────────────
async function discordFetch(token, apiPath, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': token,
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
  };
  if (body) opts.body = JSON.stringify(body);
  try {
    const res = await fetch(DISCORD_API + apiPath, opts);
    const json = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, json, headers: res.headers };
  } catch (err) {
    return { ok: false, status: 0, json: { message: err.message }, headers: null };
  }
}

// ── Smart delay with jitter (±20%) ─────────────────────
function smartDelayMs(baseMinutes) {
  const base = baseMinutes === 0 ? 2500 : baseMinutes * 60 * 1000;
  const jitter = base * 0.2;
  return Math.round(base + (Math.random() * jitter * 2 - jitter));
}

// ── Build message payload (text + optional image embed) ─
function buildPayload(message, imageUrl) {
  const payload = { content: message || '' };
  if (imageUrl && imageUrl.trim()) {
    payload.embeds = [{
      image: { url: imageUrl.trim() },
      color: 0x5865F2,
    }];
  }
  return payload;
}

// ── Autopost Engine (supports multi-channel) ───────────
function startJob(project) {
  if (runningJobs[project.id]?.running) return;

  const channels = project.channelIds && project.channelIds.length
    ? project.channelIds
    : (project.channelId ? [project.channelId] : []);

  if (!channels.length) {
    console.log(`[SKIP] Project "${project.name}" has no channels`);
    return;
  }

  console.log(`[START] Project "${project.name}" → ${channels.length} channel(s)`);

  runningJobs[project.id] = {
    running: true,
    nextSendAt: null,
    channelIndex: 0,
  };
  db.setProjectRunning(project.id, true).catch(err => console.error('[DB ERR]', err.message));

  const doSend = async () => {
    if (!runningJobs[project.id]?.running) return;

    const p = await db.getProject(project.id);
    if (!p || !p.running) { stopJob(project.id); return; }

    const chans = p.channelIds && p.channelIds.length ? p.channelIds : (p.channelId ? [p.channelId] : []);
    if (!chans.length) { stopJob(project.id); return; }

    // Round-robin through channels
    const job = runningJobs[project.id];
    const idx = job.channelIndex % chans.length;
    const channelId = chans[idx];
    job.channelIndex = (idx + 1) % chans.length;

    const payload = buildPayload(p.message, p.imageUrl);

    const { ok, status, json } = await discordFetch(
      p.token,
      `/channels/${channelId}/messages`,
      'POST',
      payload
    );

    if (ok) {
      await db.recordSuccess(project.id, new Date().toISOString());
      console.log(`[OK] #${channelId} → sent`);
    } else {
      const errMsg = json.message || json.code || `HTTP ${status}`;
      console.log(`[FAIL] #${channelId} → ${errMsg}`);

      // Rate limited → wait longer
      if (status === 429) {
        const retryAfter = (json.retry_after || 5) * 1000;
        console.log(`[RATE] Waiting ${retryAfter}ms`);
        runningJobs[project.id].nextSendAt = Date.now() + retryAfter;
        runningJobs[project.id].timer = setTimeout(doSend, retryAfter);
        await db.recordFailure(project.id, `Rate limited, retry in ${Math.round(retryAfter/1000)}s`, false);
        return;
      }

      // Critical errors → stop
      const stopOn = [401, 403, 404];
      const shouldStop = stopOn.includes(status);
      await db.recordFailure(project.id, errMsg, shouldStop);
      if (shouldStop) {
        stopJob(project.id);
        return;
      }
    }

    // Smart next delay
    const delayMs = smartDelayMs(p.delay ?? 5);
    runningJobs[project.id].nextSendAt = Date.now() + delayMs;
    runningJobs[project.id].timer = setTimeout(doSend, delayMs);
  };

  // First send after short delay
  runningJobs[project.id].nextSendAt = Date.now() + 2000;
  runningJobs[project.id].timer = setTimeout(doSend, 2000);
}

function stopJob(projectId) {
  const job = runningJobs[projectId];
  if (job) {
    job.running = false;
    if (job.timer) clearTimeout(job.timer);
    delete runningJobs[projectId];
  }
  db.setProjectRunning(projectId, false).catch(err => console.error('[DB ERR]', err.message));
  console.log(`[STOP] Project ${projectId}`);
}

// Resume running projects on server start
async function resumeJobs() {
  try {
    const all = await db.getAllProjects();
    for (const p of all) {
      if (p.running && p.token && (p.channelIds?.length || p.channelId) && p.message) {
        console.log(`[RESUME] ${p.name}`);
        startJob(p);
      }
    }
  } catch (err) {
    console.error('[RESUME ERR]', err.message);
  }
}

// ── Auth ───────────────────────────────────────────────
app.post('/api/auth/validate', async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'Token required' });

  const { ok, json } = await discordFetch(token, '/users/@me');
  if (!ok) return res.status(401).json({ error: 'Invalid token', detail: json.message });

  const user = {
    id: json.id,
    username: json.username,
    discriminator: json.discriminator || '0',
    avatar: json.avatar,
  };
  await db.upsertAccount({ ...user, token });
  res.json({ user });
});

// ── Auto-detect: Guilds ────────────────────────────────
app.get('/api/guilds', async (req, res) => {
  const token = req.headers.authorization || req.query.token;
  if (!token) return res.status(401).json({ error: 'Token required' });

  const { ok, json } = await discordFetch(token, '/users/@me/guilds');
  if (!ok) return res.status(ok ? 200 : 401).json({ error: json.message || 'Failed to fetch guilds' });

  // Return simplified list
  const guilds = (json || []).map(g => ({
    id: g.id,
    name: g.name,
    icon: g.icon,
  }));
  res.json(guilds);
});

// ── Auto-detect: Channels of a guild ───────────────────
app.get('/api/guilds/:guildId/channels', async (req, res) => {
  const token = req.headers.authorization || req.query.token;
  if (!token) return res.status(401).json({ error: 'Token required' });

  const { ok, json } = await discordFetch(token, `/guilds/${req.params.guildId}/channels`);
  if (!ok) return res.status(400).json({ error: json.message || 'Failed to fetch channels' });

  // Only text channels (type 0) and announcement (type 5)
  const channels = (json || [])
    .filter(c => c.type === 0 || c.type === 5)
    .map(c => ({
      id: c.id,
      name: c.name,
      type: c.type,
      position: c.position,
    }))
    .sort((a, b) => a.position - b.position);

  res.json(channels);
});

// ── Projects CRUD ──────────────────────────────────────
app.get('/api/projects', async (req, res) => {
  try {
    const userId = req.query.userId;
    if (!userId) return res.status(400).json({ error: 'userId required' });
    const projects = await db.getProjectsByUser(userId);
    res.json(projects);
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

app.post('/api/projects', async (req, res) => {
  try {
    const { userId, token, name, channelIds, message, imageUrl, delay } = req.body;
    if (!userId || !token) return res.status(400).json({ error: 'userId and token required' });

    const project = await db.createProject({
      id: uuidv4(),
      userId,
      token,
      name: name || 'New Project',
      channelIds: Array.isArray(channelIds) ? channelIds : [],
      message: message || '',
      imageUrl: imageUrl || '',
      delay: delay ?? 5,
    });
    res.json(project);
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

app.put('/api/projects/:id', async (req, res) => {
  try {
    const { name, channelIds, message, imageUrl, delay, token } = req.body;
    const p = await db.updateProject(req.params.id, {
      name, channelIds, message, imageUrl, delay, token,
    });
    if (!p) return res.status(404).json({ error: 'Not found' });
    res.json(p);
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

app.delete('/api/projects/:id', async (req, res) => {
  try {
    stopJob(req.params.id);
    await db.deleteProject(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

// Start / Stop
app.post('/api/projects/:id/start', async (req, res) => {
  try {
    const p = await db.getProject(req.params.id);
    if (!p) return res.status(404).json({ error: 'Not found' });
    const hasChannels = (p.channelIds && p.channelIds.length) || p.channelId;
    if (!hasChannels || !p.message) return res.status(400).json({ error: 'channel(s) and message required' });
    if (!p.token) return res.status(400).json({ error: 'No token for this project' });

    startJob(p);
    res.json({ ok: true, message: 'Autopost started' });
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

app.post('/api/projects/:id/stop', (req, res) => {
  stopJob(req.params.id);
  res.json({ ok: true, message: 'Autopost stopped' });
});

// Stats
app.get('/api/projects/:id/stats', async (req, res) => {
  try {
    const p = await db.getProject(req.params.id);
    if (!p) return res.status(404).json({ error: 'Not found' });

    const job = runningJobs[p.id];
    const running = !!(p.running || job?.running);
    let nextSendIn = null;
    if (running && job?.nextSendAt) {
      nextSendIn = Math.max(0, Math.round((job.nextSendAt - Date.now()) / 1000));
    }

    res.json({
      id: p.id,
      running,
      sent: p.sent || 0,
      failed: p.failed || 0,
      lastSent: p.lastSent,
      lastError: p.lastError,
      nextSendIn,
      channelCount: (p.channelIds || []).length || (p.channelId ? 1 : 0),
    });
  } catch (err) {
    res.status(500).json({ error: 'Database error', detail: err.message });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    const projects = await db.getAllProjects();
    const activeJobs = Object.keys(runningJobs).length;
    res.json({ status: 'ok', activeJobs, projects: projects.length, uptime: process.uptime() });
  } catch (err) {
    res.status(500).json({ status: 'error', detail: err.message });
  }
});

// ── Start ──────────────────────────────────────────────
async function main() {
  await db.init();

  if (process.env.VERCEL) {
    module.exports = app;
  } else {
    app.listen(PORT, () => {
      console.log(`✅ Discord Autoposter v2.1 running on port ${PORT}`);
      console.log(`🌐 Open: http://localhost:${PORT}`);
      resumeJobs();
    });
  }
}

main().catch(err => {
  console.error('❌ Failed to start server:', err.message);
  process.exit(1);
});

if (process.env.VERCEL) {
  module.exports = app;
}
