/* ─────────────────────────────────────────────────────
   Discord Autoposter — app.js v2.1
   Features: Auto Detect Server/Channel, Multi Channel,
   Image support, Smart Cooldown, Emoji Animate
   ───────────────────────────────────────────────────── */

const STORE_KEY = 'dap_v2_session';

let state = {
  token: null,
  user: null,
  projects: [],
  activeProjectId: null,
  guilds: [],
  channelsCache: {}, // guildId -> channels[]
};

const pollers = {};

function $(id) { return document.getElementById(id); }

function saveSession() {
  localStorage.setItem(STORE_KEY, JSON.stringify({ token: state.token, user: state.user }));
}

function loadSession() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return false;
    const data = JSON.parse(raw);
    state.token = data.token || null;
    state.user  = data.user  || null;
    return !!(state.token && state.user);
  } catch { return false; }
}

function clearSession() {
  localStorage.removeItem(STORE_KEY);
}

async function api(path, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(path, opts);
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

async function validateToken(token) {
  const { ok, json } = await api('/api/auth/validate', 'POST', { token });
  if (!ok) return null;
  return json.user;
}

async function fetchProjects() {
  if (!state.user) return;
  const { ok, json } = await api(`/api/projects?userId=${encodeURIComponent(state.user.id)}`);
  if (ok && Array.isArray(json)) state.projects = json;
}

// ── Auto Detect Guilds ────────────────────────────────
async function loadGuilds() {
  if (!state.token) return;
  const { ok, json } = await api(`/api/guilds?token=${encodeURIComponent(state.token)}`);
  if (ok && Array.isArray(json)) {
    state.guilds = json;
    const sel = $('cfg-guild');
    sel.innerHTML = '<option value="">— Pilih Server —</option>';
    json.forEach(g => {
      const opt = document.createElement('option');
      opt.value = g.id;
      opt.textContent = g.name;
      sel.appendChild(opt);
    });
  } else {
    toast('Gagal load server. Coba refresh.', 'error');
  }
}

async function loadChannels(guildId) {
  const sel = $('cfg-channels');
  sel.innerHTML = '<option value="" disabled>Loading...</option>';

  if (!guildId) {
    sel.innerHTML = '<option value="" disabled>Pilih server dulu...</option>';
    return;
  }

  if (state.channelsCache[guildId]) {
    renderChannelOptions(state.channelsCache[guildId]);
    return;
  }

  const { ok, json } = await api(`/api/guilds/${guildId}/channels?token=${encodeURIComponent(state.token)}`);
  if (ok && Array.isArray(json)) {
    state.channelsCache[guildId] = json;
    renderChannelOptions(json);
  } else {
    sel.innerHTML = '<option value="" disabled>Gagal load channel</option>';
  }
}

function renderChannelOptions(channels) {
  const sel = $('cfg-channels');
  sel.innerHTML = '';
  if (!channels.length) {
    sel.innerHTML = '<option value="" disabled>Tidak ada text channel</option>';
    return;
  }
  channels.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = `# ${c.name}`;
    sel.appendChild(opt);
  });
}

function getSelectedChannelIds() {
  const sel = $('cfg-channels');
  return Array.from(sel.selectedOptions).map(o => o.value).filter(Boolean);
}

// ── Toast ─────────────────────────────────────────────
function toast(msg, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  $(name === 'login' ? 'login-screen' : 'app-screen').classList.add('active');
}

function setUserChip(user) {
  $('user-name').textContent = user.username;
  $('user-id').textContent = user.discriminator !== '0' ? `#${user.discriminator}` : '';
  const av = $('user-avatar');
  if (user.avatar) {
    av.style.backgroundImage = `url(https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64)`;
    av.textContent = '';
  } else {
    av.style.backgroundImage = '';
    av.textContent = user.username[0].toUpperCase();
  }
}

function log(msg, type = 'info') {
  const body = $('log-body');
  if (body.querySelector('.log-empty')) body.innerHTML = '';
  const line = document.createElement('div');
  line.className = `log-line ${type}`;
  const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  line.innerHTML = `<span class="log-time">${time}</span> ${msg}`;
  body.prepend(line);
}

// ── Project List ──────────────────────────────────────
function renderProjectList() {
  const list = $('project-list');
  if (!state.projects.length) {
    list.innerHTML = '<div class="project-empty">Belum ada project</div>';
    return;
  }
  list.innerHTML = state.projects.map(p => {
    const chCount = (p.channelIds && p.channelIds.length) || (p.channelId ? 1 : 0);
    const active = p.id === state.activeProjectId ? 'active' : '';
    const running = p.running ? '<span class="dot-running"></span>' : '';
    return `
      <div class="project-card ${active}" data-id="${p.id}" onclick="selectProject('${p.id}')">
        <div class="project-card-name">${running}${escapeHtml(p.name || 'Untitled')}</div>
        <div class="project-card-sub">${chCount} channel${chCount !== 1 ? 's' : ''}</div>
      </div>`;
  }).join('');
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function getActiveProject() {
  return state.projects.find(p => p.id === state.activeProjectId);
}

async function selectProject(id) {
  state.activeProjectId = id;
  renderProjectList();
  const p = getActiveProject();
  if (!p) {
    $('empty-state').style.display = '';
    $('project-panel').style.display = 'none';
    return;
  }
  $('empty-state').style.display = 'none';
  $('project-panel').style.display = '';
  $('panel-title').textContent = p.name || 'Project';

  $('cfg-name').value = p.name || '';
  $('cfg-message').value = p.message || '';
  $('cfg-image').value = p.imageUrl || '';
  $('cfg-delay').value = p.delay != null ? p.delay : 5;

  // Restore selected channels if possible
  // We don't know which guild, so leave guild empty and let user re-select
  // Or try to keep previous selection visually
  $('cfg-guild').value = '';
  $('cfg-channels').innerHTML = '<option value="" disabled>Pilih server untuk load channel...</option>';

  // Pre-select if we have channel IDs stored (show them as selected after load)
  // For simplicity, user re-selects server then channels

  updateStartStopUI(p.running);
  startPolling(id);
  log(`Project "${p.name}" dibuka`, 'info');
}

function updateStartStopUI(running) {
  const btn = $('start-stop-btn');
  const label = $('start-stop-label');
  const startIcon = $('start-icon');
  const stopIcon = $('stop-icon');
  if (running) {
    btn.classList.add('running');
    label.textContent = 'Stop Autopost';
    startIcon.style.display = 'none';
    stopIcon.style.display = '';
  } else {
    btn.classList.remove('running');
    label.textContent = 'Mulai Autopost';
    startIcon.style.display = '';
    stopIcon.style.display = 'none';
  }
}

// ── Polling ───────────────────────────────────────────
function startPolling(projectId) {
  stopPolling(projectId);
  pollers[projectId] = setInterval(async () => {
    if (state.activeProjectId !== projectId) return;
    const { ok, json } = await api(`/api/projects/${projectId}/stats`);
    if (!ok) return;
    $('stat-sent').textContent = json.sent || 0;
    $('stat-failed').textContent = json.failed || 0;
    $('stat-channels').textContent = json.channelCount || 0;
    if (json.nextSendIn != null) {
      const m = Math.floor(json.nextSendIn / 60);
      const s = json.nextSendIn % 60;
      $('stat-countdown').textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    } else {
      $('stat-countdown').textContent = '--:--';
    }
    updateStartStopUI(json.running);
    // sync local project running state
    const p = state.projects.find(x => x.id === projectId);
    if (p) p.running = json.running;
  }, 2000);
}

function stopPolling(projectId) {
  if (pollers[projectId]) {
    clearInterval(pollers[projectId]);
    delete pollers[projectId];
  }
}

// ── Actions ───────────────────────────────────────────
async function addProject() {
  const name = prompt('Nama project baru:', 'Project Baru');
  if (!name) return;
  const { ok, json } = await api('/api/projects', 'POST', {
    userId: state.user.id,
    token: state.token,
    name,
    channelIds: [],
    message: '',
    imageUrl: '',
    delay: 5,
  });
  if (!ok) {
    toast(json.error || 'Gagal buat project', 'error');
    return;
  }
  state.projects.push(json);
  renderProjectList();
  selectProject(json.id);
  toast('Project dibuat', 'success');
}

async function saveConfig() {
  const p = getActiveProject();
  if (!p) return;

  const name = $('cfg-name').value.trim();
  const message = $('cfg-message').value;
  const imageUrl = $('cfg-image').value.trim();
  const delay = parseFloat($('cfg-delay').value) || 0;
  const channelIds = getSelectedChannelIds();

  if (!name) { toast('Nama project wajib diisi', 'error'); return; }
  if (!channelIds.length) { toast('Pilih minimal 1 channel', 'error'); return; }
  if (!message.trim() && !imageUrl) { toast('Isi pesan atau URL gambar', 'error'); return; }

  const { ok, json } = await api(`/api/projects/${p.id}`, 'PUT', {
    name,
    channelIds,
    message,
    imageUrl,
    delay,
    token: state.token,
  });

  if (!ok) {
    toast(json.error || 'Gagal simpan', 'error');
    return;
  }

  // update local
  const idx = state.projects.findIndex(x => x.id === p.id);
  if (idx >= 0) state.projects[idx] = json;
  $('panel-title').textContent = json.name;
  renderProjectList();
  toast('Config tersimpan ✓', 'success');
  log(`Config disimpan · ${channelIds.length} channel`, 'success');
}

async function toggleStartStop() {
  const p = getActiveProject();
  if (!p) return;

  // Always save latest before start
  const channelIds = getSelectedChannelIds();
  if (!p.running) {
    if (!channelIds.length && !(p.channelIds && p.channelIds.length)) {
      toast('Pilih channel dulu lalu Simpan Config', 'error');
      return;
    }
    // auto-save if channels selected
    if (channelIds.length) {
      await saveConfig();
    }
  }

  const endpoint = p.running ? 'stop' : 'start';
  const { ok, json } = await api(`/api/projects/${p.id}/${endpoint}`, 'POST');
  if (!ok) {
    toast(json.error || `Gagal ${endpoint}`, 'error');
    return;
  }

  p.running = !p.running;
  updateStartStopUI(p.running);
  renderProjectList();

  if (p.running) {
    log('▶ Autopost dimulai di server. Boleh tutup website, tetap jalan 24/7.', 'success');
    toast('Autopost dimulai', 'success');
  } else {
    log('⏹ Autopost dihentikan', 'info');
    toast('Autopost dihentikan', 'info');
  }
}

async function deleteProject(id) {
  stopPolling(id);
  const { ok } = await api(`/api/projects/${id}`, 'DELETE');
  if (!ok) { toast('Gagal hapus', 'error'); return; }
  state.projects = state.projects.filter(p => p.id !== id);
  if (state.activeProjectId === id) {
    state.activeProjectId = null;
    $('empty-state').style.display = '';
    $('project-panel').style.display = 'none';
  }
  renderProjectList();
  toast('Project dihapus', 'info');
}

function insertEmoji(emoji) {
  const ta = $('cfg-message');
  const start = ta.selectionStart;
  const end = ta.selectionEnd;
  ta.value = ta.value.slice(0, start) + emoji + ta.value.slice(end);
  ta.selectionStart = ta.selectionEnd = start + emoji.length;
  ta.focus();
}

// ── Event Bindings ────────────────────────────────────
$('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const token = $('token-input').value.trim();
  if (!token) return;

  const btn = $('login-btn');
  const btnText = $('login-btn-text');
  const spinner = $('login-spinner');
  btn.disabled = true;
  btnText.style.display = 'none';
  spinner.style.display = '';

  const user = await validateToken(token);
  btn.disabled = false;
  btnText.style.display = '';
  spinner.style.display = 'none';

  if (!user) {
    toast('❌ Token tidak valid!', 'error');
    return;
  }

  state.token = token;
  state.user = user;
  saveSession();
  await mountApp();
});

$('toggle-token-vis').addEventListener('click', () => {
  const input = $('token-input');
  const eye = $('eye-icon');
  const eyeOff = $('eye-off-icon');
  if (input.type === 'password') {
    input.type = 'text';
    eye.style.display = 'none';
    eyeOff.style.display = '';
  } else {
    input.type = 'password';
    eye.style.display = '';
    eyeOff.style.display = 'none';
  }
});

async function mountApp() {
  setUserChip(state.user);
  await fetchProjects();
  renderProjectList();
  showScreen('app');
  await loadGuilds();

  if (state.projects.length === 1) {
    selectProject(state.projects[0].id);
  }
}

$('add-project-btn').addEventListener('click', addProject);
$('save-config-btn').addEventListener('click', saveConfig);
$('start-stop-btn').addEventListener('click', toggleStartStop);
$('delete-project-btn').addEventListener('click', () => {
  const p = getActiveProject();
  if (!p) return;
  if (confirm(`Hapus project "${p.name}"?`)) deleteProject(p.id);
});
$('clear-log-btn').addEventListener('click', () => {
  $('log-body').innerHTML = '<div class="log-empty">Log dibersihkan.</div>';
});
$('logout-btn').addEventListener('click', () => {
  Object.keys(pollers).forEach(stopPolling);
  state.token = null;
  state.user = null;
  state.projects = [];
  state.activeProjectId = null;
  state.guilds = [];
  state.channelsCache = {};
  clearSession();
  $('token-input').value = '';
  showScreen('login');
  toast('Logout berhasil. Autopost aktif tetap jalan di server.', 'info');
});

$('cfg-guild').addEventListener('change', (e) => {
  loadChannels(e.target.value);
});

(async function init() {
  if (loadSession()) {
    await mountApp();
  } else {
    showScreen('login');
  }
})();
